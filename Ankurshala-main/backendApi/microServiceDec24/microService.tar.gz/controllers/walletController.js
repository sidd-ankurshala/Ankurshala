const Wallet = require('../models/Wallet');

// Create a new wallet for a user and an appId
exports.createWalletForUser = async (req, res) => {
    try {
        const wallet = new Wallet(req.body);
        await wallet.save();
        res.status(201).json(wallet);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Retrieve a user's wallet balance for a specific appId
exports.getWalletByUserIdAndAppId = async (req, res) => {
    try {
        const { userId, appId } = req.params;
        const wallet = await Wallet.findOne({ userId, appId });
        // if (!wallet) return res.status(404).json({ message: 'Wallet not found' });
        if (!wallet) {
            const newWallet = new Wallet({
                userId,
                appId,
                wallets: {}
            });
            await newWallet.save();
            res.status(201).json(newWallet);
            return;
        }
        res.status(200).json(wallet);
        return;
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Add/update funds to a wallet type
exports.addFundsToWalletType = async (req, res) => {
    try {
        const { userId, appId, type } = req.params;
        const { amount } = req.body;  // Assuming you send the amount to be added as request body

        const updatedWallet = await Wallet.findOneAndUpdate(
            { userId, appId },
            { $inc: { [`wallets.${type}`]: amount } },
            { new: true }
        );

        if (!updatedWallet) return res.status(404).json({ message: 'Wallet not found' });
        res.status(200).json(updatedWallet);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
